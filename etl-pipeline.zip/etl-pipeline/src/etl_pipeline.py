"""
AWS ETL Pipeline — Rakesh Varma Dongari
Extracts data from S3, transforms with PySpark, loads into Redshift
"""

import boto3
import logging
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date, upper, trim, when, lit
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, DateType
from config.settings import AWS_CONFIG, REDSHIFT_CONFIG, S3_CONFIG

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)
logger = logging.getLogger(__name__)


# ── Spark Session ─────────────────────────────────────────────────────────────
def create_spark_session(app_name: str = "AWS-ETL-Pipeline") -> SparkSession:
    """Initialize Spark session with AWS configurations."""
    spark = (
        SparkSession.builder
        .appName(app_name)
        .config("spark.hadoop.fs.s3a.access.key", AWS_CONFIG["access_key"])
        .config("spark.hadoop.fs.s3a.secret.key", AWS_CONFIG["secret_key"])
        .config("spark.hadoop.fs.s3a.endpoint", "s3.amazonaws.com")
        .config("spark.jars.packages", "org.apache.hadoop:hadoop-aws:3.3.1")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("WARN")
    logger.info("Spark session created successfully.")
    return spark


# ── Extract ───────────────────────────────────────────────────────────────────
def extract(spark: SparkSession, s3_path: str):
    """
    Extract raw data from S3.
    Supports CSV, JSON, Parquet formats.
    """
    logger.info(f"Extracting data from: {s3_path}")
    file_format = s3_path.split(".")[-1].lower()

    if file_format == "csv":
        df = spark.read.option("header", "true").option("inferSchema", "true").csv(s3_path)
    elif file_format == "json":
        df = spark.read.option("multiLine", "true").json(s3_path)
    elif file_format == "parquet":
        df = spark.read.parquet(s3_path)
    else:
        raise ValueError(f"Unsupported file format: {file_format}")

    logger.info(f"Extracted {df.count()} records from S3.")
    return df


# ── Transform ─────────────────────────────────────────────────────────────────
def transform(df):
    """
    Apply data transformations:
    - Drop nulls in critical columns
    - Standardize text fields
    - Parse date columns
    - Add audit columns
    """
    logger.info("Starting data transformations...")

    # Drop rows with nulls in key columns
    df = df.dropna(subset=["id", "date", "amount"])

    # Standardize string columns
    string_cols = [f.name for f in df.schema.fields if isinstance(f.dataType, StringType)]
    for c in string_cols:
        df = df.withColumn(c, trim(upper(col(c))))

    # Parse date column
    if "date" in df.columns:
        df = df.withColumn("date", to_date(col("date"), "yyyy-MM-dd"))

    # Handle negative amounts
    if "amount" in df.columns:
        df = df.withColumn(
            "amount",
            when(col("amount") < 0, lit(0.0)).otherwise(col("amount"))
        )

    # Add audit columns
    from pyspark.sql.functions import current_timestamp
    df = df.withColumn("etl_loaded_at", current_timestamp())
    df = df.withColumn("etl_source", lit("s3-pipeline"))

    logger.info(f"Transformation complete. Records after cleaning: {df.count()}")
    return df


# ── Load ──────────────────────────────────────────────────────────────────────
def load_to_redshift(df, table_name: str):
    """
    Load transformed DataFrame into Amazon Redshift.
    Uses JDBC with append or overwrite mode.
    """
    logger.info(f"Loading data into Redshift table: {table_name}")

    redshift_url = (
        f"jdbc:redshift://{REDSHIFT_CONFIG['host']}:{REDSHIFT_CONFIG['port']}"
        f"/{REDSHIFT_CONFIG['database']}"
    )

    df.write \
        .format("jdbc") \
        .option("url", redshift_url) \
        .option("dbtable", table_name) \
        .option("user", REDSHIFT_CONFIG["user"]) \
        .option("password", REDSHIFT_CONFIG["password"]) \
        .option("driver", "com.amazon.redshift.jdbc42.Driver") \
        .mode("append") \
        .save()

    logger.info(f"Successfully loaded {df.count()} records into {table_name}.")


def load_to_s3_parquet(df, output_path: str):
    """Save transformed data back to S3 as Parquet (staging/backup)."""
    logger.info(f"Writing Parquet output to: {output_path}")
    df.write.mode("overwrite").parquet(output_path)
    logger.info("Parquet write complete.")


# ── Orchestrate ───────────────────────────────────────────────────────────────
def run_pipeline():
    logger.info("=" * 60)
    logger.info("  AWS ETL PIPELINE — RAKESH VARMA DONGARI")
    logger.info("=" * 60)

    spark = create_spark_session()

    try:
        # EXTRACT
        raw_df = extract(spark, S3_CONFIG["input_path"])

        # TRANSFORM
        clean_df = transform(raw_df)

        # LOAD — Redshift
        load_to_redshift(clean_df, REDSHIFT_CONFIG["target_table"])

        # LOAD — S3 Parquet backup
        load_to_s3_parquet(clean_df, S3_CONFIG["output_path"])

        logger.info("Pipeline completed successfully ✅")

    except Exception as e:
        logger.error(f"Pipeline failed: {e}")
        raise

    finally:
        spark.stop()
        logger.info("Spark session stopped.")


if __name__ == "__main__":
    run_pipeline()
